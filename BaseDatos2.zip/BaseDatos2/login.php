<?php
require_once "config.php";
require_once "helpers.php";

$body = leer_json();
$correo = trim($body["correo"] ?? "");
$contrasena = $body["contrasena"] ?? "";

if ($correo === "" || $contrasena === "") {
  responder(false, ["error" => "Faltan datos"], 400);
}

$stmt = $pdo->prepare("SELECT id_usuario, nombre, contrasena_hash FROM usuarios WHERE correo = ?");
$stmt->execute([$correo]);
$usuario = $stmt->fetch();

if (!$usuario || !password_verify($contrasena, $usuario["contrasena_hash"])) {
  responder(false, ["error" => "Credenciales incorrectas"], 401);
}

responder(true, [
  "id_usuario" => (int)$usuario["id_usuario"],
  "nombre" => $usuario["nombre"] ?? ""
]);
