<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/helpers.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  responder(false, ["error" => "Método no permitido. Usa POST."], 405);
}

$datos = json_decode(file_get_contents("php://input"), true);
if (!is_array($datos)) {
  responder(false, ["error" => "JSON inválido"], 400);
}

$idUsuario = (int)($datos["id_usuario"] ?? 0);
$titulo = trim((string)($datos["titulo"] ?? ""));
$descripcion = array_key_exists("descripcion", $datos) ? (string)$datos["descripcion"] : null;

$prioridad = (string)($datos["prioridad"] ?? "media");
$estado = (string)($datos["estado"] ?? "pendiente");

$idEtiqueta = $datos["id_etiqueta"] ?? null;
$idEtiqueta = ($idEtiqueta === null || $idEtiqueta === "") ? null : (int)$idEtiqueta;

$fechaVencimiento = $datos["fecha_vencimiento"] ?? null;
$fechaVencimiento = ($fechaVencimiento === null || $fechaVencimiento === "") ? null : (string)$fechaVencimiento;

$latitud = $datos["latitud"] ?? null;
$latitud = ($latitud === null || $latitud === "") ? null : (float)$latitud;

$longitud = $datos["longitud"] ?? null;
$longitud = ($longitud === null || $longitud === "") ? null : (float)$longitud;

$direccion = $datos["direccion"] ?? null;
$direccion = ($direccion === null || $direccion === "") ? null : (string)$direccion;

$prioridadesValidas = ["baja", "media", "alta"];
$estadosValidos = ["pendiente", "en_progreso", "hecha"];

if ($idUsuario <= 0) responder(false, ["error" => "id_usuario inválido"], 400);
if ($titulo === "") responder(false, ["error" => "titulo es obligatorio"], 422);
if (!in_array($prioridad, $prioridadesValidas, true)) responder(false, ["error" => "prioridad inválida"], 422);
if (!in_array($estado, $estadosValidos, true)) responder(false, ["error" => "estado inválido"], 422);

try {
  $stmt = $pdo->prepare("
    INSERT INTO tareas (id_usuario, id_etiqueta, titulo, descripcion, prioridad, estado, fecha_vencimiento, latitud, longitud, direccion)
    VALUES (:id_usuario, :id_etiqueta, :titulo, :descripcion, :prioridad, :estado, :fecha_vencimiento, :latitud, :longitud, :direccion)
  ");

  $stmt->execute([
    ":id_usuario" => $idUsuario,
    ":id_etiqueta" => $idEtiqueta,
    ":titulo" => $titulo,
    ":descripcion" => $descripcion,
    ":prioridad" => $prioridad,
    ":estado" => $estado,
    ":fecha_vencimiento" => $fechaVencimiento,
    ":latitud" => $latitud,
    ":longitud" => $longitud,
    ":direccion" => $direccion
  ]);

  responder(true, ["id_tarea" => (int)$pdo->lastInsertId()], 201);

} catch (Throwable $e) {
  responder(false, ["error" => "Error al crear tarea"], 500);
}
