<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/helpers.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  responder(false, ["error" => "Método no permitido. Usa POST."], 405);
}

$datos = json_decode(file_get_contents("php://input"), true);
if (!is_array($datos)) responder(false, ["error" => "JSON inválido"], 400);

$idUsuario = (int)($datos["id_usuario"] ?? 0);
$idTarea = (int)($datos["id_tarea"] ?? 0);

if ($idUsuario <= 0 || $idTarea <= 0) {
  responder(false, ["error" => "id_usuario o id_tarea inválido"], 400);
}

$prioridadesValidas = ["baja", "media", "alta"];
$estadosValidos = ["pendiente", "en_progreso", "hecha"];

$titulo = array_key_exists("titulo", $datos) ? trim((string)$datos["titulo"]) : null;
$descripcion = array_key_exists("descripcion", $datos) ? (string)$datos["descripcion"] : null;
$prioridad = array_key_exists("prioridad", $datos) ? (string)$datos["prioridad"] : null;
$estado = array_key_exists("estado", $datos) ? (string)$datos["estado"] : null;

$idEtiqueta = array_key_exists("id_etiqueta", $datos) ? $datos["id_etiqueta"] : "__NO__";
if ($idEtiqueta !== "__NO__") $idEtiqueta = ($idEtiqueta === null || $idEtiqueta === "") ? null : (int)$idEtiqueta;

$fechaVencimiento = array_key_exists("fecha_vencimiento", $datos) ? $datos["fecha_vencimiento"] : "__NO__";
if ($fechaVencimiento !== "__NO__") $fechaVencimiento = ($fechaVencimiento === null || $fechaVencimiento === "") ? null : (string)$fechaVencimiento;

$latitud = array_key_exists("latitud", $datos) ? $datos["latitud"] : "__NO__";
if ($latitud !== "__NO__") $latitud = ($latitud === null || $latitud === "") ? null : (float)$latitud;

$longitud = array_key_exists("longitud", $datos) ? $datos["longitud"] : "__NO__";
if ($longitud !== "__NO__") $longitud = ($longitud === null || $longitud === "") ? null : (float)$longitud;

$direccion = array_key_exists("direccion", $datos) ? $datos["direccion"] : "__NO__";
if ($direccion !== "__NO__") $direccion = ($direccion === null || $direccion === "") ? null : (string)$direccion;

if ($prioridad !== null && !in_array($prioridad, $prioridadesValidas, true)) responder(false, ["error" => "prioridad inválida"], 422);
if ($estado !== null && !in_array($estado, $estadosValidos, true)) responder(false, ["error" => "estado inválido"], 422);

$campos = [];
$parametros = [":id_tarea" => $idTarea, ":id_usuario" => $idUsuario];

if ($titulo !== null) { $campos[] = "titulo = :titulo"; $parametros[":titulo"] = $titulo; }
if ($descripcion !== null) { $campos[] = "descripcion = :descripcion"; $parametros[":descripcion"] = $descripcion; }
if ($prioridad !== null) { $campos[] = "prioridad = :prioridad"; $parametros[":prioridad"] = $prioridad; }
if ($estado !== null) { $campos[] = "estado = :estado"; $parametros[":estado"] = $estado; }

if ($idEtiqueta !== "__NO__") { $campos[] = "id_etiqueta = :id_etiqueta"; $parametros[":id_etiqueta"] = $idEtiqueta; }
if ($fechaVencimiento !== "__NO__") { $campos[] = "fecha_vencimiento = :fecha_vencimiento"; $parametros[":fecha_vencimiento"] = $fechaVencimiento; }
if ($latitud !== "__NO__") { $campos[] = "latitud = :latitud"; $parametros[":latitud"] = $latitud; }
if ($longitud !== "__NO__") { $campos[] = "longitud = :longitud"; $parametros[":longitud"] = $longitud; }
if ($direccion !== "__NO__") { $campos[] = "direccion = :direccion"; $parametros[":direccion"] = $direccion; }

if (count($campos) === 0) responder(false, ["error" => "No hay campos para actualizar"], 400);

try {
  $sql = "UPDATE tareas SET " . implode(", ", $campos) . " WHERE id_tarea = :id_tarea AND id_usuario = :id_usuario";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($parametros);

  responder(true, ["actualizadas" => $stmt->rowCount()], 200);

} catch (Throwable $e) {
  responder(false, ["error" => "Error al actualizar tarea"], 500);
}
