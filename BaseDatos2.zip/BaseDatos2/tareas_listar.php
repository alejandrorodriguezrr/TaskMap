<?php
require_once "config.php";
require_once "helpers.php";

$idUsuario = (int)($_GET["id_usuario"] ?? 0);
$estado = $_GET["estado"] ?? null;

if ($idUsuario <= 0) {
  responder(false, ["error" => "id_usuario inválido"], 400);
}

if ($estado) {
  $stmt = $pdo->prepare("SELECT * FROM tareas WHERE id_usuario = ? AND estado = ? ORDER BY fecha_vencimiento IS NULL, fecha_vencimiento ASC, fecha_creacion DESC");
  $stmt->execute([$idUsuario, $estado]);
} else {
  $stmt = $pdo->prepare("SELECT * FROM tareas WHERE id_usuario = ? ORDER BY fecha_vencimiento IS NULL, fecha_vencimiento ASC, fecha_creacion DESC");
  $stmt->execute([$idUsuario]);
}

$tareas = $stmt->fetchAll();
responder(true, ["tareas" => $tareas]);
