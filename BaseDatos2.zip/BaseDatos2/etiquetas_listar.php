<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/helpers.php";

$idUsuario = (int)($_GET["id_usuario"] ?? 0);
if ($idUsuario <= 0) responder(false, ["error" => "id_usuario inválido"], 400);

$stmt = $pdo->prepare("SELECT * FROM etiquetas WHERE id_usuario = ? ORDER BY nombre ASC");
$stmt->execute([$idUsuario]);

responder(true, ["etiquetas" => $stmt->fetchAll()], 200);
