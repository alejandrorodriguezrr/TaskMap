<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/helpers.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  responder(false, ["error" => "Método no permitido. Usa POST."], 405);
}

$datos = json_decode(file_get_contents("php://input"), true);
if (!is_array($datos)) responder(false, ["error" => "JSON inválido"], 400);

$idUsuario = (int)($datos["id_usuario"] ?? 0);
$idTarea = (int)($datos["id_tarea"] ?? 0);

if ($idUsuario <= 0 || $idTarea <= 0) {
  responder(false, ["error" => "id_usuario o id_tarea inválido"], 400);
}

try {
  $stmt = $pdo->prepare("DELETE FROM tareas WHERE id_tarea = ? AND id_usuario = ?");
  $stmt->execute([$idTarea, $idUsuario]);

  responder(true, ["borradas" => $stmt->rowCount()], 200);

} catch (Throwable $e) {
  responder(false, ["error" => "Error al borrar tarea"], 500);
}
