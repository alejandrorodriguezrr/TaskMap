<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/config.php';

try {
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('No existe $pdo en DataBase.php.');
    }

    $metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // =========================
    // GET -> listar / obtener
    // =========================
    if ($metodo === 'GET') {

        // Opcional: /archivo.php?id_usuario=5
        $id_usuario = isset($_GET['id_usuario']) ? (int)$_GET['id_usuario'] : 0;

        // Opcional: /archivo.php?correo=a@a.com
        $correo = isset($_GET['correo']) ? trim((string)$_GET['correo']) : '';

        if ($id_usuario > 0) {
            $stmt = $pdo->prepare('
                SELECT id_usuario, nombre, correo, fecha_creacion
                FROM usuarios
                WHERE id_usuario = :id
                LIMIT 1
            ');
            $stmt->execute([':id' => $id_usuario]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'usuario' => $usuario], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($correo !== '') {
            if (mb_strlen($correo) > 180 || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                http_response_code(422);
                echo json_encode(['ok' => false, 'error' => 'correo inválido.'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $stmt = $pdo->prepare('
                SELECT id_usuario, nombre, correo, fecha_creacion
                FROM usuarios
                WHERE correo = :correo
                LIMIT 1
            ');
            $stmt->execute([':correo' => $correo]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'usuario' => $usuario], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // Listado completo
        $stmt = $pdo->query('
            SELECT id_usuario, nombre, correo, fecha_creacion
            FROM usuarios
            ORDER BY id_usuario DESC
        ');
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['ok' => true, 'usuarios' => $usuarios], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // =========================
    // POST -> registrar
    // =========================
    if ($metodo !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Método no permitido. Usa GET o POST.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);

    if (!is_array($data)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'JSON inválido.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $nombre = isset($data['nombre']) ? trim((string)$data['nombre']) : null;
    $correo = isset($data['correo']) ? trim((string)$data['correo']) : '';
    $contrasena = isset($data['contrasena']) ? (string)$data['contrasena'] : '';

    if ($correo === '' || mb_strlen($correo) > 180 || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'correo es obligatorio y debe ser válido (máx 180).'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($contrasena === '' || mb_strlen($contrasena) < 4) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'contrasena es obligatoria (mínimo 4 caracteres).'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($nombre !== null && $nombre !== '' && mb_strlen($nombre) > 80) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'nombre máximo 80 caracteres.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $hash = password_hash($contrasena, PASSWORD_DEFAULT);

    // (Opcional pero recomendable) comprobar si ya existe antes del INSERT
    $stmt = $pdo->prepare('SELECT id_usuario FROM usuarios WHERE correo = :correo LIMIT 1');
    $stmt->execute([':correo' => $correo]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['ok' => false, 'error' => 'Ese correo ya existe.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $sql = 'INSERT INTO usuarios (nombre, correo, contrasena_hash)
            VALUES (:nombre, :correo, :hash)';

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nombre' => ($nombre === '' ? null : $nombre),
        ':correo' => $correo,
        ':hash'   => $hash
    ]);

    http_response_code(201);
    echo json_encode(['ok' => true, 'id_usuario' => (int)$pdo->lastInsertId()], JSON_UNESCAPED_UNICODE);
    exit;

} catch (PDOException $e) {

    // Duplicado (MySQL 1062)
    if (isset($e->errorInfo[1]) && (int)$e->errorInfo[1] === 1062) {
        http_response_code(409);
        echo json_encode(['ok' => false, 'error' => 'Ese correo ya existe.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Error interno.', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Error interno.', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}
