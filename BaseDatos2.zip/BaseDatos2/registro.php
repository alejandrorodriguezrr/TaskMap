<?php
header("Content-Type: application/json; charset=utf-8");

// DEBUG (quítalo cuando funcione)
ini_set("display_errors", "1");
ini_set("display_startup_errors", "1");
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode(["ok" => false, "error" => "Método no permitido"]);
    exit;
}

require_once __DIR__ . "/config.php";

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    echo json_encode(["ok" => false, "error" => "La conexión PDO no está disponible"]);
    exit;
}

$cuerpo = file_get_contents("php://input");
$datos = json_decode($cuerpo, true);

if (!is_array($datos)) {
    http_response_code(400);
    echo json_encode(["ok" => false, "error" => "JSON inválido", "recibido" => $cuerpo]);
    exit;
}

$nombre = trim($datos["nombre"] ?? "");
$correo = trim($datos["correo"] ?? "");
$contrasena = (string)($datos["contrasena"] ?? "");

if ($nombre === "" || $correo === "" || $contrasena === "") {
    http_response_code(400);
    echo json_encode(["ok" => false, "error" => "Faltan campos"]);
    exit;
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["ok" => false, "error" => "Correo inválido"]);
    exit;
}

try {
    $sentencia = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE correo = :correo LIMIT 1");
    $sentencia->execute([":correo" => $correo]);

    if ($sentencia->fetch()) {
        http_response_code(409);
        echo json_encode(["ok" => false, "error" => "Correo ya existe"]);
        exit;
    }

    $hash = password_hash($contrasena, PASSWORD_BCRYPT);

    $sentencia = $pdo->prepare("
        INSERT INTO usuarios (nombre, correo, contrasena_hash)
        VALUES (:nombre, :correo, :contrasena_hash)
    ");

    $sentencia->execute([
        ":nombre" => $nombre,
        ":correo" => $correo,
        ":contrasena_hash" => $hash
    ]);

    http_response_code(201);
    echo json_encode(["ok" => true, "id_usuario" => (int)$pdo->lastInsertId()]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "error" => "PDOException",
        "mensaje" => $e->getMessage(),
        "errorInfo" => $e->errorInfo
    ]);
}
