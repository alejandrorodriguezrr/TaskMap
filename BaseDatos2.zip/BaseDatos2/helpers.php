<?php
function leer_json() {
  $raw = file_get_contents("php://input");
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function responder($ok, $data = [], $codigo = 200) {
  http_response_code($codigo);
  echo json_encode(array_merge(["ok" => $ok], $data));
  exit;
}
