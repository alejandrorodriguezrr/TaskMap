<?php
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/helpers.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  responder(false, ["error" => "Método no permitido. Usa POST."], 405);
}

$datos = json_decode(file_get_contents("php://input"), true);
if (!is_array($datos)) responder(false, ["error" => "JSON inválido"], 400);

$idUsuario = (int)($datos["id_usuario"] ?? 0);
$nombre = trim((string)($datos["nombre"] ?? ""));

if ($idUsuario <= 0) responder(false, ["error" => "id_usuario inválido"], 400);
if ($nombre === "" || mb_strlen($nombre) > 40) responder(false, ["error" => "nombre inválido"], 422);

try {
  $stmt = $pdo->prepare("INSERT INTO etiquetas (id_usuario, nombre) VALUES (?, ?)");
  $stmt->execute([$idUsuario, $nombre]);

  responder(true, ["id_etiqueta" => (int)$pdo->lastInsertId()], 201);

} catch (PDOException $e) {
  if ((string)$e->getCode() === "23000") {
    responder(false, ["error" => "Se repite la etiqueta"], 409);
  }
  responder(false, ["error" => "Error al crear etiqueta"], 500);
}
